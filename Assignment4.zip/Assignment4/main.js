//a. Calculate the Average rating for all the restaurants. 
const ratingData = [
    { restaurant: 'KFC', rating: 5 },
    { restaurant: 'Burger King', rating: 4 },
    { restaurant: 'KFC', rating: 3 },
    { restaurant: 'Domino', rating: 2 },
    { restaurant: 'Subway', rating: 3 },
    { restaurant: 'Domino', rating: 1 },
    { restaurant: 'Subway', rating: 4 },
    { restaurant: 'Pizza Hut', rating: 5 }
  ];
  
  const restaurantData = {};
  
  ratingData.forEach(({ restaurant, rating }) => {
    // If the restaurant is already in the restaurantData object
    if (restaurantData.hasOwnProperty(restaurant)) {
      // Add the rating to the existing total rating
      restaurantData[restaurant].totalRating += rating;
      restaurantData[restaurant].count++;
    } else {
      // If the restaurant is not in the restaurantData object
      // Create a new entry for the restaurant with the initial rating and count
      restaurantData[restaurant] = { totalRating: rating, count: 1 };
    }
  });
  
  // Calculation of  the average rating for each restaurant
  const averageRatings = Object.keys(restaurantData).map(restaurant => {
    const { totalRating, count } = restaurantData[restaurant];
    const averageRating = totalRating / count;
    return { restaurant, averageRating };
  });
  
 
  console.log(averageRatings);


  //b. List of all restaurants with average rating greater than or equal to 4.  

const filteredRestaurants = averageRatings.filter(({ averageRating }) => averageRating >= 4);

console.log(filteredRestaurants);