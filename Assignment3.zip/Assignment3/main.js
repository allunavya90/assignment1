//1. Create a JavaScript restaurantManager class with the following properties: 

class RestaurantManager {
    constructor() {
      this.restaurantList = [];
    }
  
    addRestaurant(name, address, city) {
      this.restaurantList.push({ name, address, city });
    }
  
    printAllRestaurantNames() {
      for (let restaurant of this.restaurantList) {
        console.log(restaurant.name);
      }
    }
  

  
    filterRestaurantByCity(city) {
        const filteredRestaurants = this.restaurantList.filter(
          (restaurant) => restaurant.city === city
        );
    
        return filteredRestaurants;
      }
    }

  const manager = new RestaurantManager();
  // Add restaurants
  manager.addRestaurant("Bawarchi", "CRTC X Rd,Chikkadpally", "Hyderabad");
  manager.addRestaurant("Chutneys", "Road No. 1, Jubilee Hills", "Hyderabad");
  manager.addRestaurant("Time Traveller", "Electronic City", "Bangalore");
  manager.addRestaurant("Rayalaseema Ruchulu", "Rd Number 36, Jubilee Hills", "Hyderabad");
  
  
  // Print all restaurant names
  manager.printAllRestaurantNames(); // Output: Bawarchi, Chutneys, Time Traveller,Rayalaseema Ruchulu
  
  // Filter restaurants by city
  const filteredRestaurants = manager.filterRestaurantByCity("Hyderabad");
  console.log(filteredRestaurants);
  // Output: [{ name: "Bawarchi", address: "CRTC X Rd,Chikkadpally", city: "Hyderabad" },
  //           { name: "Chutneys", address: "Road No. 1, Jubilee Hills", city: "Hyderabad" },
  //          { name: "Rayalaseema Ruchulu", address: "Rd Number 36, Jubilee Hills", city: "Hyderabad" }]

//2. Please find order details for Punjabi Tadka restaurant in Delhi as: ⮚orderData = { 'Below 500': 20, '500-1000': 29, '1000-1500': 30, '1500-2000': 44, 'Above 2000': 76 };    
//a. Calculate the total number of orders placed for the restaurant?. 
const orderData = {
    'Below 500': 20,
    '500-1000': 29,
    '1000-1500': 30,
    '1500-2000': 44,
    'Above 2000': 76
  };
  
  let totalOrders = 0;
  
  for (let orderRange in orderData) {
    totalOrders += orderData[orderRange];
  }  // output:Total number of orders: 199

  
  console.log('Total number of orders:', totalOrders); 

//b. Calculate the number of order proportion options. 

  
  const orderProportionOptions = Object.keys(orderData).length;
  
  console.log('Number of order proportion options:', orderProportionOptions);// output: Number of order proportion options: 5

  // c. Calculate the percentage of each proportion in below format:
  //{id: 2,order: "500-1000",order percentage: "14.57",restaurant: "Punjabi Tadka"},
  const orderData1 = {
    'Below 500': 20,
    '500-1000': 29,
    '1000-1500': 30,
    '1500-2000': 44,
    'Above 2000': 76
  };
  
  const totalOrders1 = Object.values(orderData1).reduce((total, value) => total + value, 0);
  
  const orderProportions = Object.entries(orderData1).map(([order, count], index) => {
    const percentage = ((count / totalOrders1) * 100).toFixed(2);
    return {
      id: index + 1,
      order,
      orderPercentage: percentage,
      restaurant: 'Punjabi Tadka'
    };
  });
  
  console.log(orderProportions);
  
  