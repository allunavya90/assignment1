const express = require("express");
const app = express();
const AppRouter = require("./routes/Approuting");

app.use("/",AppRouter);

app.listen(3040,()=>{
    console.log("app is running on port no 3040");
})
