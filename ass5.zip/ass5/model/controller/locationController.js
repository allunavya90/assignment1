
const Location = require("../model/location.json");

const LocationController = {
    getLocationList: (request, response) => {
        let locationList=[];
        const cityList =   Location.map( location => [location.name]);
        locationList.push(cityList);
        response.send(locationList);
    }
}



module.exports = LocationController;