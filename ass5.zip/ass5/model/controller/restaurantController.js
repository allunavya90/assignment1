const restaurantData = require("../model/restaurantData.json");

const RestaurantController = {
getSingleRestaurant: (request, response) => {
    let { city_name } = request.params;
    // to read data from params we us ==> response.params
    let result =  restaurantData.filter((value, index) => {
      return value.city_name === city_name;
    });
    if (result.length === 0) {
      response.send({ status: false });
    } else {
      response.send(result);
    }
  }


}
  module.exports = RestaurantController;