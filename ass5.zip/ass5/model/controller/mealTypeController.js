const mealType = require("../model/mealType.json");

const MealTypeController = {
getMealType: (request, response) => {
  let mealArray=[];
  mealType.map( (meal, index)=> {
    const mealObj = {
      "id": meal._id,
      "name":meal.name,
      "meal_type":index + 1

    }
    mealArray.push(mealObj);
  }
   )
   response.send(mealArray);
  }



}

  module.exports = MealTypeController;
