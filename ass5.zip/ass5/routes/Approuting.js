const express= require("express");
const AppRouter =  express.Router();
const  LocationController =require("../controller/locationController");
const RestaurantController = require("../controller/restaurantController")
const MealTypeController = require("../controller/mealTypeController");

AppRouter.get("/get-location-list",LocationController.getLocationList);
AppRouter.get(
    "/get-single-restaurant/:city_name",
    RestaurantController.getSingleRestaurant
  );
AppRouter.get("/widget",MealTypeController.getMealType);


module.exports= AppRouter;